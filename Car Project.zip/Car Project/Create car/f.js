// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

let createForm = document.querySelector(".createForm")

let marka = document.querySelector("#validationCustom01")
let model = document.querySelector("#validationCustom02")
let yurus = document.querySelector("#validationCustom03")
let elaqeNomresi = document.querySelector("#validationCustom04")
let masinSekli = document.querySelector("#validationCustom05")
let tesvir = document.querySelector("#validationCustom06")
let YanacaqNovu = document.querySelector("#validationCustom07")
let masinIli = document.querySelector("#validationCustom08")

let user = JSON.parse(localStorage.getItem("user"))
let users = JSON.parse(localStorage.getItem("users"))

let cars = JSON.parse(localStorage.getItem("cars")) || []

function generateID() {
  if (cars.length > 0) {
    return cars[cars.length - 1].id + 1
  }
  else {
    return 1
  }
}

createForm.addEventListener("submit", (e) => {
  e.preventDefault()

  if (createForm.checkValidity()) {
    let car = {
      id: generateID(),
      marka: marka.value,
      model: model.value,
      yurus: marka.value,
      elaqeNomresi: elaqeNomresi.value,
      masinSekli: masinSekli.value,
      tesvir: tesvir.value,
      YanacaqNovu: YanacaqNovu.value,
      masinIli: masinIli.value,
      masininSahibi: user.username
    }

    console.log(car);
    cars.push(car)
    localStorage.setItem("cars",JSON.stringify(cars))
  }
  else {
    console.log("Elave oluna bilmez!");
  }
})
