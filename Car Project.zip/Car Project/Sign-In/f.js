let form = document.querySelector("form")
let username = document.querySelector("#validationCustom01")
let password = document.querySelector("#validationCustom02")
let toastBootstrap1 = new bootstrap.Toast(document.querySelector("#liveToast"))
let toastBootstrap2 = new bootstrap.Toast(document.querySelector("#liveToast2"))

let users = JSON.parse(localStorage.getItem("users")) || []

form.addEventListener("submit", function (e) {
    e.preventDefault()

    if (form.checkValidity()) {
        let user = users.find(function (e) {
            if (e.username === username.value && e.password === password.value) {
                return e
            }
        })

        if (user) {
            localStorage.setItem("user", JSON.stringify(user))
            toastBootstrap2.show()
            setTimeout(() => {
                location.href = "../Home/f.html"
            }, 1000);
        }
        else {
            toastBootstrap1.show()
        }

        console.log(user);
    }
})