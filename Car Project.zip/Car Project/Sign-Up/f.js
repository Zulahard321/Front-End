// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

// // // //

let form = document.querySelector("form")
let firstname = document.querySelector("#validationCustom01")
let lastname = document.querySelector("#validationCustom02")
let username = document.querySelector("#validationCustom03")
let email = document.querySelector("#validationCustom04")
let password = document.querySelector("#validationCustom05")
let profileimg = document.querySelector("#validationCustom06")

let users = JSON.parse(localStorage.getItem("users")) || []



form.addEventListener("submit", (e) => {
  e.preventDefault()

  if (form.checkValidity()) {
    let check = users.some(function (item) {
      return username.value == item.username
    })

    if (check) {
      alert("Bu istifadeci adini yaza bilmersiniz")
    }
    else {
      let user = {
        firstname: firstname.value,
        lastname: lastname.value,
        username: username.value,
        email: email.value,
        password: password.value,
        profileimg: profileimg.value,
        cars: []
      }

      users.push(user)
      localStorage.setItem("users", JSON.stringify(users))
      location.href = "../Sign-In/f.html"
    }
  }

  else {
    console.log("Yanlishdir");
  }
})