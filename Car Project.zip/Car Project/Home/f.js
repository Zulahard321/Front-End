let cars = JSON.parse(localStorage.getItem("cars")) || []

let carsParent = document.querySelector(".carsParent")

cars.forEach(car => {
  let element = `
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="${car.masinSekli}" alt="" style="height: 200px;">
                <div class="card-body">
                    <h2>${car.marka}</h2>
                    <p>${car.model}</p>
                    <p>${car.tesvir}</p>
                    <button class="btn btn-primary ">Tesvir</button>
                </div>
            </div>
  `

  carsParent.innerHTML += element
});

//Submit  halinda --> Buttonu tesdiqlemekdir requiredler isleyir
//Click halinda --> Sadece olaraq buttona klikleyir 