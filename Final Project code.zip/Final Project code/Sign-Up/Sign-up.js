// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

// // // //
let toastBootstrap1 = new bootstrap.Toast(document.querySelector("#liveToast"))
let toastBootstrap2 = new bootstrap.Toast(document.querySelector("#liveToast2"))

let form = document.querySelector("form")
let Ad = document.querySelector("#validationCustom01")
let Telefon = document.querySelector("#validationCustom02")
let Istifadeciad = document.querySelector("#validationCustom03")
let password = document.querySelector("#validationCustom04")

let users = JSON.parse(localStorage.getItem("users")) || []

let btninfo = document.querySelector(".btn-info")
let btnwarning = document.querySelector(".btn-warning")

form.addEventListener("submit", (e) => {
  e.preventDefault()

  if (form.checkValidity()) {
    let check = users.some(function (item) {
      return Istifadeciad.value == item.Istifadeciad
    })

    if (check) {
      toastBootstrap1.show()
    }
    else {
      let user = {
        Ad: Ad.value,
        Telefon: Telefon.value,
        Istifadeciad: Istifadeciad.value,
        password: password.value,
      }

      users.push(user)
      localStorage.setItem("users", JSON.stringify(users))
      toastBootstrap2.show()
      setTimeout(() => {
                location.href = "../Sign-In/Sign-in.html"
      }, 1000);
    }
  }

  else {
    console.log("Yanlishdir");
  }
})

btninfo.addEventListener("click", () => {
  location.href = "../Sign-In/Sign-in.html"
})
btnwarning.addEventListener("click", () => {
  location.href = "../Home/Home.html"
})