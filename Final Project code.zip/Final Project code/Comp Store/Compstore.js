const myModal = document.getElementById('exampleModal')

let btnwarning = document.querySelector(".btn-warning")

btnwarning.addEventListener("click", () => {
  location.href = "../Home/Home.html"
})

let user = JSON.parse(localStorage.getItem("user"))
let users = JSON.parse(localStorage.getItem("users"))

let comps = JSON.parse(localStorage.getItem("comps")) || []
let comp = JSON.parse(localStorage.getItem("comp")) || []

let modal1 = document.querySelector(".modal1")
let compsParent = document.querySelector(".compsParent")

let spinner = document.querySelector(".spinner")


function displayComp(lastComps) {
  compsParent.innerHTML = ""
  lastComps.forEach(comp => {
    let element = `
            <div class = "col-3">
              <div class="card" style="width: 15rem; height:350px; margin:auto; padding:10px">
                <img class="card-img-top" src="${comp.Sekil}" alt="" style="height: 150px;">
                <div class="card-body">
                    <p>Ad:${comp.Ad}</p>
                    <p>Tesvir:${comp.Tesvir}</p>
                    <p>Qiymet:${comp.Qiymeti}</p>
                    <p>Yeni:${comp.Yeni}</p>
                    <p><b>Telefon:${comp.Telefon}</b></p>
                    <div style="display:flex; justify-content:center; align-items:center;">
                    <button class="btn btn-primary etrafli" onclick="compInfo(${comp.id}), openmodal()">Etrafli</button>
                    </div>
                </div>
              </div>
            <div>
  `

    compsParent.innerHTML += element
  });
}

setTimeout(() => {
  spinner.classList.add("show")
}, 300);

setTimeout(() => {
  displayComp(comps)
}, 300);



let modal = new bootstrap.Modal(document.querySelector(".modal"))
function openmodal() {
  modal.show()
}
//Submit  halinda --> Buttonu tesdiqlemekdir requiredler isleyir
//Click halinda --> Sadece olaraq buttona klikleyir 

let modalRight = document.querySelector(".modal-body")
function compInfo(compId) {
  let comp = comps.find(function (item) {
    return item.id == compId
  })
  modalRight.innerHTML = `
  <div class="image" style = "display:flex; justify-content:center; align-items:center;">
    <img class="etraflisekil" src="${comp.Sekil}" alt="" style ="width:300px">
  </div>
  <p class="Kateqoriya"><b>Kateqoriya:</b>${comp.Kateqoriya}</p>
<p class="Ad"><b>Ad:</b>${comp.Ad}</p>  
<p class="Emeliyaddas"><b>Emeliyaddas:</b>${comp.Emeliyaddas}</p>
<p class="Merkeziprosessor"><b>Merkeziprosessor:</b>${comp.Merkeziprosessor}</p>
<p class="Qiymet"><b>Qiymet:</b>${comp.Qiymeti}</p>
<p class="Daimiyaddas"><b>Daimiyaddas:</b>${comp.Daimiyaddas}</p>
<p class="Tesvir"><b>Tesvir:</b>${comp.Tesvir}</p>
<p class="Yeni"><b>Yeni:</b>${comp.Yeni}</p>
<p class="Emeliyyatsistemi"><b>Emeliyyatsistemi:</b>${comp.Emeliyyatsistemi}</p>
<p class="Videokart"><b>Videokart:</b>${comp.Videokart}</p>
<p class="Compsahibi"><b>Compsahibi:</b>${user.Istifadeciad}</p>
  `
}

// compInfo()

function modalfade(compId) {
  let findcomp = comps.find(function (comp) {
    return comp.id == compId
  })
  modal1.show()
}

let input = document.querySelector(".searchInput")
input.addEventListener("input", () => {
  let filterComp = comps.filter(function (comp) {
    return comp.Ad.includes(input.value)
  })
  displayComp(filterComp)
})

let listItems = document.querySelectorAll(".chooseComp a")

listItems.forEach(function (item) {
  item.addEventListener("click", (e) => {
    let filterComps = comps.filter(function (comp) {
      if (e.target.innerHTML.toLowerCase() == "hamisi") {
        return comps
      }
      else {
        return comp.Kateqoriya.toLowerCase().includes(e.target.innerHTML.toLowerCase())
      }
    })
    displayComp(filterComps)
  })
})

