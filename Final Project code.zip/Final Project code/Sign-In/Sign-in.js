// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
    'use strict'

    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    const forms = document.querySelectorAll('.needs-validation')

    // Loop over them and prevent submission
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
            }

            form.classList.add('was-validated')
        }, false)
    })
})()

let form = document.querySelector("form")
let username = document.querySelector("#validationCustom01")
let password = document.querySelector("#validationCustom02")
let toastBootstrap1 = new bootstrap.Toast(document.querySelector("#liveToast"))
let toastBootstrap2 = new bootstrap.Toast(document.querySelector("#liveToast2"))
let btninfo = document.querySelector(".btn-info")
let btnwarning = document.querySelector(".btn-warning")

let users = JSON.parse(localStorage.getItem("users")) || []

form.addEventListener("submit", function (e) {
    e.preventDefault()

    if (form.checkValidity()) {
        let user = users.find(function (e) {
            console.log(e.Istifadeciad, e.password, password.value,username.value);
            return e.Istifadeciad == username.value && e.password == password.value
        })

        if (user) {
            localStorage.setItem("user", JSON.stringify(user))
            toastBootstrap2.show()
            setTimeout(() => {
                location.href = "../Home/Home.html"
            }, 1000);
        }
        else {
            toastBootstrap1.show()
        }

        console.log(user);
    }
})

btninfo.addEventListener("click", () => {
    location.href = "../Sign-Up/Sign-up.html"
})
btnwarning.addEventListener("click", () => {
    location.href = "../Home/Home.html"
})