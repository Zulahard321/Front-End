const myCarouselElement = document.querySelector('#carouselExampleCaptions')

const carousel = new bootstrap.Carousel(myCarouselElement, {
    interval: 2000
})

// 

let compbtn = document.querySelector(".compstorebtn")
let qeydbtn = document.querySelector(".signinbtn")
let mycompbtn = document.querySelector(".mycompbtn")

compbtn.addEventListener("click", () => {
    location.href = "../Comp Store/Compstore.html"
})

qeydbtn.addEventListener("click", () => {
    location.href = "../Sign-Up/Sign-up.html"
})

mycompbtn.addEventListener("click", () => {
    location.href = "../My computer/Computerim.html"
})


let compstorebtn = document.querySelector(".compstorebtn")
let signinbtn = document.querySelector(".signinbtn")
let signoutbtn = document.querySelector(".signoutbtn")
let ad = document.querySelector(".ad")
let user = JSON.parse(localStorage.getItem("user")) || []
let users = JSON.parse(localStorage.getItem("users")) || []

function checkUser() {
    if (typeof user === "object") {
        let checkUser = users.find(function (e) {
            return e.Istifadeciad === user.Istifadeciad && e.password === user.password
        })

        if (!checkUser) {
            mycompbtn.style.display = "none"
            signoutbtn.style.display = "none"
        }
        else {
            ad.innerHTML = user.Istifadeciad
            signinbtn.style.display = "none"
            signinbtn.style.display = "none"
        }
    }
    else {
        console.log("obyekt deil");
    }
}

signoutbtn.addEventListener("click", () => {
    localStorage.removeItem("user")
    location.reload()
})

checkUser()