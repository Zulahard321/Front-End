// Example starter JavaScript for disabling form submissions if there are invalid fields
(() => {
  'use strict'

  // Fetch all the forms we want to apply custom Bootstrap validation styles to
  const forms = document.querySelectorAll('.needs-validation')

  // Loop over them and prevent submission
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventdefault()
        event.stopPropagation()
      }

      form.classList.add('was-validated')
    }, false)
  })
})()

let table = new DataTable('#myTable');

const myModal = document.getElementById('exampleModal')

let Esassehife = document.querySelector(".Home")
Esassehife.addEventListener("click", () => {
  location.href = "../Home/Home.html"
})

// Deyerler
let createForm = document.querySelector(".createForm")
let Kateqoriya = document.querySelector("#validationCustom01")
let Emeliyaddas = document.querySelector("#validationCustom02")
let Ad = document.querySelector("#validationCustom03")
let Merkeziprosessor = document.querySelector("#validationCustom04")
let Qiymeti = document.querySelector("#validationCustom05")
let Daimiyaddas = document.querySelector("#validationCustom06")
let Tesvir = document.querySelector("#validationCustom07")
let Daimiyaddastipi = document.querySelector("#validationCustom08")
let Yeni = document.querySelector("#validationCustom09")
let Emeliyyatsistemi = document.querySelector("#validationCustom010")
let Sekil = document.querySelector("#validationCustom011")
let Videokart = document.querySelector("#validationCustom012")
let img = document.querySelector("img")
const tbody = document.querySelector("tbody")

let user = JSON.parse(localStorage.getItem("user"))
let users = JSON.parse(localStorage.getItem("users"))

let comps = JSON.parse(localStorage.getItem("comps")) || []
let comp = JSON.parse(localStorage.getItem("comp"))

function generateID() {
  if (comps.length > 0) {
    return comps[comps.length - 1].id + 1
  }
  else {
    return 1
  }
}

img.src = Sekil.innerHTML

console.log(img.src);

createForm.addEventListener("submit", (e) => {
  e.preventDefault()

  if (createForm.checkValidity()) {
    let comp = {
      id: generateID(),
      Kateqoriya: Kateqoriya.value,
      Emeliyaddas: Emeliyaddas.value,
      Ad: Ad.value,
      Merkeziprosessor: Merkeziprosessor.value,
      Qiymeti: Qiymeti.value,
      Daimiyaddas: Daimiyaddas.value,
      Tesvir: Tesvir.value,
      Daimiyaddastipi: Daimiyaddastipi.value,
      Yeni: Yeni.value,
      Emeliyyatsistemi: Emeliyyatsistemi.value,
      Sekil: Sekil.value,
      Videokart: Videokart.value,
      Telefon: user.Telefon,
      CompSahibi: user.Istifadeciad
    }

    console.log(comp);
    comps.push(comp)
    localStorage.setItem("comps", JSON.stringify(comps))
    displayComps();
    location.reload()

    // if (Ad.value && Sekil.value && Qiymeti.value) {
    //   table.row.add([
    //     Ad.value, Sekil.value, Qiymeti.value

    //   ]).draw()
    // }
  }
  else {
    console.log("Elave oluna bilmez!");
  }
})

let Sifirla = document.querySelector(".sifirlamodal")
Sifirla.addEventListener("click", (e) => {
  Kateqoriya.value = ""
  Emeliyaddas.value = ""
  Ad.value = ""
  Merkeziprosessor.value = ""
  Qiymeti.value = ""
  Daimiyaddas.value = ""
  Tesvir.value = ""
  Daimiyaddastipi.value = ""
  Yeni.value = ""
  Emeliyyatsistemi.value = ""
  Sekil.value = ""
  Videokart.value = ""
})

function displayComps() {
  let myComp = comps.filter(function (comp) {
    return comp.CompSahibi == user.Istifadeciad
  })
  tbody.innerHTML = ""
  myComp.forEach(function (comp) {
    let element = `
            <tbody>
                <tr>
                  <td>${comp.id}</td>
                  <td>${comp.Ad}</td>
                  <td><img class = "cedvelimg" onclick = "compInfo(${comp.id})" src = "${comp.Sekil}"></img></td>
                  <td>${comp.Qiymeti}</td>
                  <td>
                        <button type="button" class="btn btn-danger" onclick="removeComp(${comp.id})">Sil</button>
                        <button type="button" class="btn btn-info" onclick="editComp(${comp.id})">Redakte et</button>
                  </td>
                </tr>
            </tbody>
        `

    tbody.innerHTML += element
  })

}

displayComps()

// Modal acilisi
let modal3 = new bootstrap.Modal(document.querySelector(".modal3"))
let modalRight = document.querySelector(".modalsekil")
function compInfo(compId) {
  modal3.show()
  let comp = comps.find(function (item) {
    return item.id == compId
  })
  modalRight.innerHTML = `
  <div class="image" style = "display:flex; justify-content:center; align-items:center;">
    <img class="cedvelsekil" src="${comp.Sekil}" alt="" style ="width:800px;">
  </div>
  `
}

// compInfo(comp)

function removeComp(compId) {
  let filterComps = comps.filter(function (item) {
    return item.id != compId
  })

  localStorage.setItem("comps", JSON.stringify(filterComps))
  displayComps()
  const row = event.target.closest('tr');
  table.row(row).remove().draw();
  location.reload()
}

const myModal2 = new bootstrap.Modal(document.getElementById('exampleModal2'))
let editForm = document.querySelector(".editForm")
let Kateqoriyaedit = document.querySelector("#validationCustom1")
let Emeliyaddasedit = document.querySelector("#validationCustom2")
let Adedit = document.querySelector("#validationCustom3")
let Merkeziprosessoredit = document.querySelector("#validationCustom4")
let Qiymetiedit = document.querySelector("#validationCustom5")
let Daimiyaddasedit = document.querySelector("#validationCustom6")
let Tesviredit = document.querySelector("#validationCustom7")
let Daimiyaddastipiedit = document.querySelector("#validationCustom8")
let Yeniedit = document.querySelector("#validationCustom9")
let Emeliyyatsistemiedit = document.querySelector("#validationCustom10")
let Sekiledit = document.querySelector("#validationCustom11")
let Videokartedit = document.querySelector("#validationCustom12")
let secilmiscomp;
function editComp(compId) {
  let findComp = comps.find(function (comp) {
    return comp.id == compId
  })
  secilmiscomp = compId

  console.log(findComp);
  Kateqoriyaedit.value = findComp.Kateqoriya
  Emeliyaddasedit.value = findComp.Emeliyaddas
  Adedit.value = findComp.Ad
  Merkeziprosessoredit.value = findComp.Merkeziprosessor
  Qiymetiedit.value = findComp.Qiymeti
  Daimiyaddasedit.value = findComp.Daimiyaddas
  Tesviredit.value = findComp.Tesvir
  Daimiyaddastipiedit.value = findComp.Daimiyaddastipi
  Yeniedit.value = findComp.Yeni
  Emeliyyatsistemiedit.value = findComp.Emeliyyatsistemi
  Sekiledit.value = findComp.Sekil
  Videokartedit.value = findComp.Videokart

  myModal2.show()
}

editForm.addEventListener("submit", (e) => {
  e.preventDefault()

  if (editForm.checkValidity()) {
    comps = comps.map(function (comp) {
      if (comp.id == secilmiscomp) {
        return {
          ...comp,
          Kateqoriya: Kateqoriyaedit.value,
          Emeliyaddas: Emeliyaddasedit.value,
          Ad: Adedit.value,
          Merkeziprosessor: Merkeziprosessoredit.value,
          Qiymeti: Qiymetiedit.value,
          Daimiyaddas: Daimiyaddasedit.value,
          Tesvir: Tesviredit.value,
          Daimiyaddastipi: Daimiyaddastipiedit.value,
          Yeni: Yeniedit.value,
          Emeliyyatsistemi: Emeliyyatsistemiedit.value,
          Sekil: Sekiledit.value,
          Videokart: Videokartedit.value,
        }
      }

      return comp
    })

    localStorage.setItem("comps", JSON.stringify(comps))
    location.reload()
  }
})
